# Seller Operations & Payout Monitoring System

An end-to-end data engineering project built using Python, SQL, SQLite, and Pandas.

## Project Overview

This project simulates an e-commerce seller operations platform. It generates synthetic business data, validates data integrity, monitors seller performance, tracks order fulfillment, and identifies payout-related exceptions.

## Key Features

- Synthetic seller and product data generation
- Order and order-line management
- Shipment and delivery tracking
- Commission and reserve calculations
- Dispute and chargeback monitoring
- Payout eligibility checks
- Seller performance metrics
- Exception and anomaly detection
- Data validation and integrity checks
- CSV, JSON, and SQLite outputs
- Automated tests using Pytest

## Technology Stack

- Python
- SQL
- SQLite
- Pandas
- CSV and JSON
- Pytest
- Git and GitHub

## Project Structure

```text
Seller-Operations-Payout-Monitoring/
├── data/
│   ├── raw/
│   ├── processed/
│   ├── ground_truth/
│   ├── sql/
│   ├── README_generated.md
│   ├── source_manifest.json
│   └── validation_summary.json
├── docs/
│   └── data_dictionary.md
├── src/
│   └── generate_data.py
├── tests/
│   ├── test_exceptions.py
│   └── test_validation.py
├── .gitignore
└── README.md
